package com.programmingpoe;

import java.util.List;
import java.util.Scanner;

public class ProgrammingPOE {
    private static MessageManager messageManager = new MessageManager();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Populate with test data as per assignment
        populateTestData();

        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    messageManager.displaySenderAndRecipientOfAllMessages();
                    break;
                case 2:
                    System.out.println("Longest message: " + messageManager.getLongestMessagePayload());
                    break;
                case 3:
                    System.out.print("Enter Message ID to search: ");
                    String searchId = scanner.nextLine();
                    Message foundMessage = messageManager.searchMessageById(searchId);
                    if (foundMessage != null) {
                        System.out.println("Found message: " + foundMessage);
                    } else {
                        System.out.println("Message with ID " + searchId + " not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter Recipient to search: ");
                    String searchRecipient = scanner.nextLine();
                    List<Message> recipientMessages = messageManager.searchMessagesByRecipient(searchRecipient);
                    if (!recipientMessages.isEmpty()) {
                        System.out.println("Messages for recipient " + searchRecipient + ":");
                        for (Message msg : recipientMessages) {
                            System.out.println(msg);
                        }
                    } else {
                        System.out.println("No messages found for recipient " + searchRecipient + ".");
                    }
                    break;
                case 5:
                    System.out.print("Enter Message Hash to delete: ");
                    String deleteHash = scanner.nextLine();
                    if (messageManager.deleteMessageByHash(deleteHash)) {
                        System.out.println("Message with hash " + deleteHash + " deleted successfully.");
                    } else {
                        System.out.println("Message with hash " + deleteHash + " not found.");
                    }
                    break;
                case 6:
                    messageManager.displayReport();
                    break;
                case 0:
                    System.out.println("Exiting application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Display sender and recipient of all stored messages");
        System.out.println("2. Display the longest stored message");
        System.out.println("3. Search for a message ID and display the corresponding recipient and message");
        System.out.println("4. Search for messages received for a particular recipient");
        System.out.println("5. Delete a message using the message hash");
        System.out.println("6. Display a report that lists the full details of all the stored messages");
        System.out.println("0. Exit");
        System.out.println("-----------------");
    }

    private static void populateTestData() {
        // Test Data Message 1
        messageManager.addMessage(new Message("+27815559006", "+27812345678", "Did you get the calls?", "Sent", "hash1", "msg001"));

        // Test Data Message 2
        messageManager.addMessage(new Message("+27844449957", "+27818765432", "Where are you? You are late! I have asked you to be on time.", "Stored", "hash2", "msg002"));

        // Test Data Message 3
        messageManager.addMessage(new Message("+27814449967", "+27819876543", "Upheavals, I am at your gate.", "Discarded", "hash3", "msg003"));

        // Test Data Message 4
        messageManager.addMessage(new Message("0828888557", "+27811112222", "Is it dinner time ?", "Sent", "hash4", "msg004"));

        // Test Data Message 5
        messageManager.addMessage(new Message("+27815559957", "+27813334444", "Ok, I am leaving without you.", "Stored", "hash5", "msg005"));

        System.out.println("Test data populated.");
    }
}