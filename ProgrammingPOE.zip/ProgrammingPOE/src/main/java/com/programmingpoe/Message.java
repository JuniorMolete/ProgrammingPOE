package com.programmingpoe;

public class Message {
    private String sender;
    private String recipient;
    private String messagePayload;
    private String flag;
    private String messageHash;
    private String messageId;

    public Message(String sender, String recipient, String messagePayload, String flag, String messageHash, String messageId ) {
        this.sender = sender;
        this.recipient = recipient;
        this.messagePayload = messagePayload;
        this.flag = flag;
        this.messageHash = messageHash;
        this.messageId = messageId;
    }

    // Getters
    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessagePayload() {
        return messagePayload;
    }

    public String getFlag() {
        return flag;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getMessageId() {
        return messageId;
    }

    // Setters (if needed, though for this assignment, messages might be immutable once created)
    public void setSender(String sender) {
        this.sender = sender;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public void setMessagePayload(String messagePayload) {
        this.messagePayload = messagePayload;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public void setMessageHash(String messageHash) {
        this.messageHash = messageHash;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    @Override
    public String toString() {
        return "Sender: " + sender + ", Recipient: " + recipient + ", Message: \"" + messagePayload + "\", Flag: " + flag + ", Hash: " + messageHash + ", ID: " + messageId;
    }
}