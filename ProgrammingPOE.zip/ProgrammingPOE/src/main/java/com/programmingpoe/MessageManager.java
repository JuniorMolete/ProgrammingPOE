package com.programmingpoe;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MessageManager {
    private List<Message> messages;

    public MessageManager() {
        this.messages = new ArrayList<>();
    }

    public void addMessage(Message message) {
        this.messages.add(message);
    }

    public List<Message> getAllMessages() {
        return new ArrayList<>(messages);
    }

    public String getLongestMessagePayload() {
        if (messages.isEmpty()) {
            return "";
        }
        String longestPayload = "";
        for (Message message : messages) {
            if (message.getMessagePayload().length() > longestPayload.length()) {
                longestPayload = message.getMessagePayload();
            }
        }
        return longestPayload;
    }

    public Message searchMessageById(String messageId) {
        for (Message message : messages) {
            if (message.getMessageId().equals(messageId)) {
                return message;
            }
        }
        return null;
    }

    public List<Message> searchMessagesByRecipient(String recipient) {
        List<Message> foundMessages = new ArrayList<>();
        for (Message message : messages) {
            if (message.getRecipient().equals(recipient)) {
                foundMessages.add(message);
            }
        }
        return foundMessages;
    }

    public boolean deleteMessageByHash(String messageHash) {
        return messages.removeIf(message -> message.getMessageHash().equals(messageHash));
    }

    public void displayReport() {
        if (messages.isEmpty()) {
            System.out.println("No messages to display in the report.");
            return;
        }
        System.out.println("\n--- Message Report ---");
        for (Message message : messages) {
            System.out.println(message.toString());
        }
        System.out.println("----------------------");
    }

    public void displaySenderAndRecipientOfAllMessages() {
        if (messages.isEmpty()) {
            System.out.println("No messages to display sender and recipient.");
            return;
        }
        System.out.println("\n--- Sender and Recipient of All Messages ---");
        for (Message message : messages) {
            System.out.println("Sender: " + message.getSender() + ", Recipient: " + message.getRecipient() + ", Message ID: " + message.getMessageId());
        }
        System.out.println("--------------------------------------------");
    }
}