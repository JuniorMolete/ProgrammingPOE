package com.programmingpoe;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class MessageManagerTest {

    private MessageManager messageManager;

    @BeforeEach
    public void setUp() {
        messageManager = new MessageManager();
        // Populate with test data for tests
        messageManager.addMessage(new Message("+27815559006", "+27812345678", "Did you get the calls?", "Sent", "hash1", "msg001"));
        messageManager.addMessage(new Message("+27844449957", "+27818765432", "Where are you? You are late! I have asked you to be on time.", "Stored", "hash2", "msg002"));
        messageManager.addMessage(new Message("+27814449967", "+27819876543", "Upheavals, I am at your gate.", "Discarded", "hash3", "msg003"));
        messageManager.addMessage(new Message("0828888557", "+27811112222", "Is it dinner time ?", "Sent", "hash4", "msg004"));
        messageManager.addMessage(new Message("+27815559957", "+27813334444", "Ok, I am leaving without you.", "Stored", "hash5", "msg005"));
    }

    @Test
    public void testAddMessage() {
        Message newMessage = new Message("sender", "recipient", "payload", "flag", "hash", "id");
        messageManager.addMessage(newMessage);
        List<Message> messages = messageManager.getAllMessages();
        assertTrue(messages.contains(newMessage));
    }

    @Test
    public void testGetLongestMessagePayload() {
        String longest = messageManager.getLongestMessagePayload();
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }

    @Test
    public void testSearchMessageById() {
        Message found = messageManager.searchMessageById("msg002");
        assertNotNull(found);
        assertEquals("hash2", found.getMessageHash());
        
        Message notFound = messageManager.searchMessageById("nonexistent");
        assertNull(notFound);
    }

    @Test
    public void testSearchMessagesByRecipient() {
        List<Message> found = messageManager.searchMessagesByRecipient("+27818765432");
        assertEquals(1, found.size());
        assertEquals("msg002", found.get(0).getMessageId());
        
        List<Message> notFound = messageManager.searchMessagesByRecipient("nonexistent");
        assertTrue(notFound.isEmpty());
    }

    @Test
    public void testDeleteMessageByHash() {
        boolean deleted = messageManager.deleteMessageByHash("hash3");
        assertTrue(deleted);
        assertNull(messageManager.searchMessageById("msg003")); // Assuming ID and Hash are unique per message
        
        boolean notDeleted = messageManager.deleteMessageByHash("nonexistent");
        assertFalse(notDeleted);
    }
}